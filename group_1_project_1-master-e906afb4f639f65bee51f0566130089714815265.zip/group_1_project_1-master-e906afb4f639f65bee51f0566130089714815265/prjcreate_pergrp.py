###COMPARING AND CREATING ANY NEW PROJECTS
##STAGE-2

##LISTING ALL PROJECTS IN DC GITLAB

#with open("new123.txt") as file12:
#        lines = [l.strip() for l in file12]
#        for i in lines:
allGroupsAG = urllib2.urlopen("http://10.10.2.63/api/v3/groups?private_token=BhzxixsqEG_WEyWxnTR5&per_page=100")
allGroupsAGDICT   = json.loads(allGroupsAG.read().decode())
for thisGroup in allGroupsAGDICT:
                        #if str(thisGroup['path'])==i:
                         #       print "checkin"
        thisGroupID=str(thisGroup['id'])
                                #print thisGroupID
                                #thisGroupID=str(i)
        allProjectsAGDict1 = urllib2.urlopen("http://10.10.2.63/api/v3/groups/{0}/projects?private_token=BhzxixsqEG_WEyWxnTR5&per_page=100".format(thisGroupID))
        allProjectsDictAG = json.loads(allProjectsAGDict1.read().decode())
                               # print allProjectsDictAG
        for thisGroup1 in allProjectsDictAG:
                        #                print thisGroup1
                g=open('projectid.txt','a')
                call(["echo",str(thisGroup1['ssh_url_to_repo'])],stdout=g)

##LISTING ALL PROJECTS IN AWS GITLAB

allGroups64 = urllib2.urlopen("http://10.10.2.64/api/v3/groups?private_token=QcySbaKWbRisJ7sKWF3j&per_page=100")
allGroups64DICT   = json.loads(allGroups64.read().decode())
for thisGroup in allGroups64DICT:
                        #if str(thisGroup['path'])==i:
                         #       print "checkin"
        thisGroupID=str(thisGroup['id'])
                                #print thisGroupID
                                #thisGroupID=str(i)
        allProjectsAGDict164 = urllib2.urlopen("http://10.10.2.64/api/v3/groups/{0}/projects?private_token=QcySbaKWbRisJ7sKWF3j&per_page=100".format(thisGroupID))
        allProjectsDictAG64 = json.loads(allProjectsAGDict164.read().decode())
                               # print allProjectsDictAG
        for thisGroup1 in allProjectsDictAG64:
                        #                print thisGroup1
                g=open('projectid1.txt','a')
                call(["echo",str(thisGroup1['ssh_url_to_repo'])],stdout=g)



################################################################################################################


with open(r'projectid.txt','r') as masterdata:
        with open(r'projectid1.txt','r') as useddata:
                with open(r'diff_projects.txt','w+') as Newdata:

                        usedfile = [ x.strip('\n') for x in list(useddata) ] #1
                        masterfile = [ x.strip('\n') for x in list(masterdata) ] #2

                        for line in masterfile: #3
                                if line not in usedfile: #4
                                        Newdata.write(line + '\n') #5
#################################################################################################################
####CREATING NEW PROJECTS

#ith open("diff_projects.txt") as file1:
with open("diff_projectstest.txt") as file1:
        path = [l.strip() for l in file1]
        print "entering"
        for i in path:
                print "inside loop"
                allGroupsdiff = urllib2.urlopen("http://10.10.2.63/api/v3/projects/all?private_token=BhzxixsqEG_WEyWxnTR5&per_page=100")
                allGroups64diff   = json.loads(allGroupsdiff.read().decode())
                for thisGroup in allGroups64diff:
                        print i
                        j=str(thisGroup['ssh_url_to_repo'])
                        j=j.replace('fw-dw-apacmaven.cyber.bestinet.com', '10.10.2.64')
                        if i==j:
                                #print "wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww"
                                line='name='+str(thisGroup['name'])
                                #line='name='+str(i))
                                url="http://10.10.2.64/api/v3/projects?private_token=QcySbaKWbRisJ7sKWF3j"
                                call(["curl","-X","POST","-d",line,url])
