from subprocess import call
import urllib2
import json
import subprocess, shlex
import os


allProjectsAWS = urllib2.urlopen("http://10.10.2.64/api/v3/projects?private_token=QcySbaKWbRisJ7sKWF3j&per_page=100&page=1")
allProjectsAWS1   = json.loads(allProjectsAWS.read().decode())
for thisGroup in allProjectsAWS1:
        #g=open('grpid.txt','a')
	print thisGroup['namespace']['id']
        #j=str(thisGroup['ssh_url_repo'])
        #j=j.replace('gitlab.example.com', 'fw-dw-apacmaven.cyber.bestinet.com')
        #call(["echo",str(thisGroup['name'])],stdout=g)
