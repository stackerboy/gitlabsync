from subprocess import call
import urllib2
import json
import subprocess, shlex
import os

call['touch','file1.txt']
call['touch','file2.txt']
call['touch','file3.txt']
call['touch','file4.txt']
call['touch','name_grp.txt']
call['touch','path_grp.txt']
call['touch','diff_projects_all.txt']
call['touch','new.txt']
call['touch','file.txt']
call['touch','project_onprem.txt']
call['touch','project_aws.txt']
#call['touch','file1.txt']

#call['touch','file1.txt']









