from subprocess import call
#Running git fetch to fetch latest branches and commits in the production repository
call(["git","fetch","--all","--prune"])
#Output the text to t.ini
#The lines from git branch output will be split and written to words and a list named words1 is created
#Next will find the position of / to extract the branch name
#join the words back to string  and write into words4
#Next run the Checkout and pull command on each branch word
g=open('t.ini','w')
call(["git","branch","-r"],stdout=g)
with open('t.ini') as f:
    i=0
    for line in f:
        #print line
        words=line.split()
        words1=list(words[0])
        words2=words1.index('/')
        words3= words1[words2+1:]
        words4=''.join(words3)
        f=open('file.txt','w')
        print >>f ,words4
        call(["git","checkout",words4])
        call(["git","pull","origin",words4])
	call(["git","push","-u","AWS",words4])
#        call(["git", "branch","-r"])
#       if 'str' in line:
#          break

